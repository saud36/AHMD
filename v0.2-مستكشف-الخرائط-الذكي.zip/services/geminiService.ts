import { GoogleGenAI } from "@google/genai";
import type { SearchParams, SearchResult, UserLocation } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const buildPrompt = (params: SearchParams): string => {
  const { area, searchType, keywords, radius } = params;
  
  let searchTypeName = '';
  switch (searchType) {
    case 'contractors':
      searchTypeName = 'شركات المقاولات';
      break;
    case 'parking':
      searchTypeName = 'أماكن بها مواقف سيارات كبيرة (مثل المجمعات التجارية، الساحات العامة، مواقف الشركات الكبيرة)';
      break;
    case 'under_construction':
        searchTypeName = 'مشاريع تحت الإنشاء';
        break;
  }
  
  let prompt = `باستخدام أدوات البحث في خرائط جوجل، ابحث عن ${searchTypeName} في منطقة "${area}".\n`;

  if (radius) {
    prompt += `ضمن نطاق بحث يبلغ ${radius} كيلومتر.\n`;
  }
  if (keywords) {
    prompt += `مع التركيز على الكلمات المفتاحية التالية: "${keywords}".\n`;
  }

  prompt += "لكل نتيجة، قدم البيانات التالية: 'name', 'address', 'phone', 'mapsLink', 'website', 'rating'.\n";
  prompt += "تأكد من أن النتائج دقيقة ومحدثة. قم بإرجاع النتائج ككتلة JSON برمجية واحدة تحتوي على مصفوفة من الكائنات. لا تقم بتضمين أي نص أو تعليقات خارج كتلة JSON البرمجية.";
  
  return prompt;
};


export const fetchPlaces = async (params: SearchParams, userLocation: UserLocation | null): Promise<SearchResult[]> => {
  const prompt = buildPrompt(params);
  
  const modelName = params.useThinkingMode ? 'gemini-2.5-pro' : 'gemini-2.5-flash';

  // When using grounding tools (googleMaps, googleSearch), responseMimeType and responseSchema are not supported.
  const config: any = {
    tools: [{ googleMaps: {} }, { googleSearch: {} }],
  };

  if (params.useThinkingMode) {
    config.thinkingConfig = { thinkingBudget: 32768 };
  }

  if (userLocation) {
    config.toolConfig = {
      retrievalConfig: {
        latLng: {
          latitude: userLocation.latitude,
          longitude: userLocation.longitude,
        },
      },
    };
  }
  
  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: config,
    });

    const rawText = response.text.trim();
    if (!rawText) {
      return [];
    }
    
    // Extract JSON from markdown code block if present
    let jsonText = '';
    const jsonBlockMatch = rawText.match(/```json\s*([\s\S]*?)\s*```/);

    if (jsonBlockMatch && jsonBlockMatch[1]) {
      jsonText = jsonBlockMatch[1];
    } else {
      // Fallback for cases where the model returns raw JSON
      const startIndex = rawText.indexOf('[');
      const endIndex = rawText.lastIndexOf(']');
      if (startIndex !== -1 && endIndex !== -1) {
        jsonText = rawText.substring(startIndex, endIndex + 1);
      } else {
        console.warn("Could not find a valid JSON array in the model's response.", {rawText});
        return [];
      }
    }
    
    try {
        const parsedResults = JSON.parse(jsonText) as SearchResult[];
        return parsedResults;
    } catch (parseError) {
        console.error("Failed to parse JSON from extracted text:", parseError);
        console.error("Original model response:", rawText);
        console.error("Extracted text for parsing:", jsonText);
        throw new Error("فشل في تحليل البيانات المستلمة من النموذج. قد يكون التنسيق غير صحيح.");
    }
    
  } catch (error) {
    console.error("Error fetching data from Gemini API:", error);
    if (error instanceof Error) {
        throw error;
    }
    throw new Error("فشل في استرداد البيانات من الواجهة البرمجية. تحقق من وحدة التحكم لمزيد من التفاصيل.");
  }
};