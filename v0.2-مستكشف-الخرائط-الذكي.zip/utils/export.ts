import type { SearchResult } from '../types';

function convertToCSV(data: SearchResult[]): string {
  if (data.length === 0) {
    return '';
  }

  const headers = ['الاسم', 'العنوان', 'الهاتف', 'رابط خرائط جوجل', 'الموقع الإلكتروني', 'التقييم'];
  const rows = data.map(item => [
    `"${item.name || ''}"`,
    `"${item.address || ''}"`,
    `"${item.phone || ''}"`,
    `"${item.mapsLink || ''}"`,
    `"${item.website || ''}"`,
    `"${item.rating || ''}"`
  ]);

  return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
}

export function exportToCsv(data: SearchResult[], filename: string): void {
  const csvString = convertToCSV(data);
  const blob = new Blob([`\uFEFF${csvString}`], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
