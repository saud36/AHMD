import React, { useState } from 'react';
import type { SearchParams, SearchType } from '../types';
import BuildingIcon from './icons/BuildingIcon';
import ParkingIcon from './icons/ParkingIcon';
import CraneIcon from './icons/CraneIcon';

interface SearchFormProps {
  onSearch: (params: SearchParams) => void;
  isLoading: boolean;
}

const SearchForm: React.FC<SearchFormProps> = ({ onSearch, isLoading }) => {
  const [area, setArea] = useState<string>('');
  const [searchType, setSearchType] = useState<SearchType>('contractors');
  const [keywords, setKeywords] = useState<string>('');
  const [radius, setRadius] = useState<number>(10);
  const [useThinkingMode, setUseThinkingMode] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!area.trim()) {
      alert("الرجاء إدخال المنطقة أو المدينة للبحث.");
      return;
    }
    onSearch({ area, searchType, keywords, radius, useThinkingMode });
  };

  return (
    <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700 shadow-xl">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="area" className="block text-sm font-medium text-cyan-300 mb-2">
            المنطقة / المدينة / الحي
          </label>
          <input
            id="area"
            type="text"
            value={area}
            onChange={(e) => setArea(e.target.value)}
            placeholder="مثال: الرياض، حي العليا"
            required
            className="w-full bg-slate-900 border border-slate-600 rounded-md p-3 text-slate-200 placeholder-slate-500 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
          />
        </div>

        <div>
          <span className="block text-sm font-medium text-cyan-300 mb-3">نوع البحث</span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button
              type="button"
              onClick={() => setSearchType('contractors')}
              className={`flex items-center justify-center p-4 rounded-lg border-2 transition-all duration-200 ${searchType === 'contractors' ? 'bg-cyan-500/20 border-cyan-500 text-white' : 'bg-slate-700/50 border-slate-600 hover:border-cyan-600 text-slate-300'}`}
            >
              <BuildingIcon className="w-6 h-6 ml-3" />
              <span className="font-semibold">شركات مقاولات</span>
            </button>
            <button
              type="button"
              onClick={() => setSearchType('parking')}
              className={`flex items-center justify-center p-4 rounded-lg border-2 transition-all duration-200 ${searchType === 'parking' ? 'bg-cyan-500/20 border-cyan-500 text-white' : 'bg-slate-700/50 border-slate-600 hover:border-cyan-600 text-slate-300'}`}
            >
              <ParkingIcon className="w-6 h-6 ml-3" />
              <span className="font-semibold">مواقف سيارات</span>
            </button>
             <button
              type="button"
              onClick={() => setSearchType('under_construction')}
              className={`flex items-center justify-center p-4 rounded-lg border-2 transition-all duration-200 ${searchType === 'under_construction' ? 'bg-cyan-500/20 border-cyan-500 text-white' : 'bg-slate-700/50 border-slate-600 hover:border-cyan-600 text-slate-300'}`}
            >
              <CraneIcon className="w-6 h-6 ml-3" />
              <span className="font-semibold">مشاريع تحت الإنشاء</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="keywords" className="block text-sm font-medium text-cyan-300 mb-2">
              كلمات مفتاحية (اختياري)
            </label>
            <input
              id="keywords"
              type="text"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
              placeholder="مقاولات عامة، مواقف مغطاة"
              className="w-full bg-slate-900 border border-slate-600 rounded-md p-3 text-slate-200 placeholder-slate-500 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            />
          </div>
          <div>
            <label htmlFor="radius" className="block text-sm font-medium text-cyan-300 mb-2">
              نصف قطر البحث (كم)
            </label>
            <input
              id="radius"
              type="number"
              value={radius}
              min="1"
              max="50"
              onChange={(e) => setRadius(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-600 rounded-md p-3 text-slate-200 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
            />
          </div>
        </div>
        
        <div className="flex items-center justify-between bg-slate-700/30 p-3 rounded-lg">
           <label htmlFor="thinking-mode" className="flex flex-col">
              <span className="font-medium text-slate-200">وضع التفكير العميق</span>
              <span className="text-xs text-slate-400">للاستعلامات المعقدة، قد يستغرق وقتاً أطول.</span>
            </label>
            <div className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" id="thinking-mode" className="sr-only peer" checked={useThinkingMode} onChange={() => setUseThinkingMode(!useThinkingMode)} />
                <div className="w-11 h-6 bg-slate-600 rounded-full peer peer-focus:ring-4 peer-focus:ring-cyan-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-600"></div>
            </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 text-white font-bold py-3 px-4 rounded-md hover:from-cyan-600 hover:to-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              جاري البحث...
            </>
          ) : (
            'ابحث الآن'
          )}
        </button>
      </form>
    </div>
  );
};

export default SearchForm;