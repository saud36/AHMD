import React from 'react';

const CraneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 6v14"/>
    <path d="M12 6H4"/>
    <path d="M12 6h8a4 4 0 0 1 4 4v2"/>
    <path d="M16 10h4"/>
    <path d="M4 20h16"/>
    <path d="m8 6 4-4 4 4"/>
  </svg>
);

export default CraneIcon;