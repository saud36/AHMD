import React from 'react';
import type { SearchResult } from '../types';
import { exportToCsv } from '../utils/export';
import LoadingSpinner from './LoadingSpinner';
import MapPinIcon from './icons/MapPinIcon';
import PhoneIcon from './icons/PhoneIcon';
import GlobeIcon from './icons/GlobeIcon';
import DownloadIcon from './icons/DownloadIcon';
import CopyIcon from './icons/CopyIcon';

interface ResultsDisplayProps {
  results: SearchResult[];
  isLoading: boolean;
  searchPerformed: boolean;
}

const ResultCard: React.FC<{ result: SearchResult }> = ({ result }) => {
    const copyToClipboard = (text: string | null) => {
        if (text) {
            navigator.clipboard.writeText(text);
            // Optionally show a toast notification
        }
    };

    const InfoRow: React.FC<{ icon: React.ReactNode; label: string; value: string | null | undefined; isLink?: boolean; }> = ({ icon, label, value, isLink }) => {
        if (!value) return null;
        return (
            <div className="flex items-start text-sm group">
                <div className="flex-shrink-0 w-5 h-5 mt-0.5 text-cyan-400">{icon}</div>
                <div className="mr-3 flex-1">
                    <span className="font-semibold text-slate-300">{label}:</span>
                    {isLink ? (
                        <a href={value} target="_blank" rel="noopener noreferrer" className="mr-2 text-cyan-300 hover:text-cyan-200 hover:underline break-all">{value}</a>
                    ) : (
                        <span className="mr-2 text-slate-300 break-words">{value}</span>
                    )}
                </div>
                {!isLink && <button onClick={() => copyToClipboard(value)} className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 hover:text-white"><CopyIcon className="w-4 h-4" /></button>}
            </div>
        );
    };

    return (
        <div className="bg-slate-800/60 p-5 rounded-lg border border-slate-700 transition-all hover:border-cyan-500/50 hover:shadow-lg hover:shadow-cyan-500/10">
            <h3 className="text-xl font-bold text-cyan-300 mb-3">{result.name}</h3>
            {result.rating && <div className="absolute top-4 left-4 text-xs font-bold bg-yellow-500/20 text-yellow-300 border border-yellow-500/30 px-2 py-1 rounded-full">{`⭐ ${result.rating.toFixed(1)}`}</div>}
            <div className="space-y-3">
                <InfoRow icon={<MapPinIcon />} label="العنوان" value={result.address} />
                <InfoRow icon={<PhoneIcon />} label="الهاتف" value={result.phone} />
                <InfoRow icon={<GlobeIcon />} label="الموقع" value={result.website} isLink={true} />
                <InfoRow icon={<MapPinIcon />} label="رابط الخريطة" value={result.mapsLink} isLink={true} />
            </div>
        </div>
    );
};


const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results, isLoading, searchPerformed }) => {
  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (!searchPerformed) {
    return (
      <div className="text-center py-16 text-slate-500">
        <p>ابدأ البحث للعثور على بيانات شركات المقاولات أو مواقف السيارات.</p>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="text-center py-16 text-slate-400">
        <p>لم يتم العثور على نتائج. حاول تعديل معايير البحث.</p>
      </div>
    );
  }

  const handleExport = () => {
    exportToCsv(results, `نتائج-البحث-${new Date().toISOString().split('T')[0]}.csv`);
  };

  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-slate-200">النتائج ({results.length})</h2>
        <button
          onClick={handleExport}
          className="flex items-center bg-teal-600 hover:bg-teal-700 text-white font-semibold py-2 px-4 rounded-lg transition"
        >
          <DownloadIcon className="w-5 h-5 ml-2"/>
          تصدير إلى CSV
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {results.map((result, index) => (
          <ResultCard key={`${result.name}-${index}`} result={result} />
        ))}
      </div>
    </div>
  );
};

export default ResultsDisplay;
